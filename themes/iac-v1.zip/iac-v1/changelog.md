* [fef2307](https://github.com/TryGhost/Casper/commit/fef2307) 2.9.9 - Nazar Gargol
* [de8b837](https://github.com/TryGhost/Casper/commit/de8b837) Lock file maintenance - Renovate Bot
* [4a2e9c9](https://github.com/TryGhost/Casper/commit/4a2e9c9) Update dependency @tryghost/release-utils to v0.3.2 - Renovate Bot
* [070bed3](https://github.com/TryGhost/Casper/commit/070bed3) Update dependency gscan to v2.4.0 - Renovate Bot
* [7f8990c](https://github.com/TryGhost/Casper/commit/7f8990c) Update css processors - Renovate Bot
